const SVGFixer = require('oslllo-svg-fixer');

var options = {
  showProgressBar: true,
  throwIfDestinationDoesNotExist: false,
}
const SVG = SVGFixer('./svg', './svg', options)
SVG.fix().then(() => {
  console.log('done')
}).catch(e => {
  console.log(e)
})
