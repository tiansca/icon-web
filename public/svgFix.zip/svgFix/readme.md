### 用于将svg转换为填充/单一路径，将SVG描边转换为填充

#### 安装依赖
npm install

#### 执行转换
将svg文件放入svg路径下，然后执行node index.js
